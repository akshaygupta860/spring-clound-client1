package com.springcloudclient1.controller;

import com.springcloudclient1.model.CartConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class CartController {

    @Value("${ItemLimit}")
    private Integer itemLimit;

    @GetMapping("/cartConfiguration")
    public CartConfiguration getCartConfiguration() {
        return getConfiguration();
    }

    private CartConfiguration getConfiguration(){
        return CartConfiguration
                .builder()
                .itemLimit(itemLimit)
                .build();
    }
}
