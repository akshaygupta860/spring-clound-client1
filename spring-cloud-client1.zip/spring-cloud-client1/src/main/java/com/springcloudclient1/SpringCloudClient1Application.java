package com.springcloudclient1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudClient1Application.class, args);
	}

}
